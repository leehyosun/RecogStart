package my.data;

public class Information {
	public String value;
}
