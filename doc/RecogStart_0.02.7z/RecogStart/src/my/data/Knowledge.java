package my.data;

public class Knowledge {
	public String value;
}
