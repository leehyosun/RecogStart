package my.sensor;

import my.data.Data;
import my.surroundings.Signal;
import my.surroundings.Thing;
import my.thinker.Recognizer;

public class Sensor1 {
	private Data data;
	private Recognizer recognizer;
	
	public void setContact(Recognizer ob) {
		recognizer = ob;
	}
	
	/*
	 * �����ϴ�
	 * �ܺηκ��� Signal�� �޾� Data�� �����Ѵ�.
	 */
	public void measure(Thing t) {
		System.out.println("		Sensor.measure()");
		classify(t.signal);
		recognizer.getData(data);
	}
		
	/*
	 * ô���� ���� �з��Ѵ�.
	 */
	private void classify(Signal s) {
		data = new Data();
		
		switch (Math.abs(s.value)) {
		case 1: data.value = 'a'; break;
		case 2: data.value = 'b'; break;
		case 3: data.value = 'c'; break;
		}
	}
}
