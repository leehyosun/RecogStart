package my.thinker;

import java.util.ArrayList;

import my.data.Data;
import my.data.Information;

public class Recognizer {
	private Information info;
	private ArrayList<Data> dataList = new ArrayList<Data>();
	private Thinker thinker;
	
	public void setContact(Thinker ob) {
		thinker = ob;
	}
	
	public void getData(Data ob) {
		dataList.add(ob);
	}
	
	public void recognize() {
		info = new Information();
		System.out.println("		Recognizer.recognize()");
		
		String temp = "";
		for (Data ob : dataList) {
			//System.out.println(ob.value);
			temp += ob.value;
		}

		info.value = searchExperience(temp);
		//System.out.println(info.value);
		
		thinker.getData(info);
	}
	
	private String searchExperience(String s) {
		return s;
	}
}
