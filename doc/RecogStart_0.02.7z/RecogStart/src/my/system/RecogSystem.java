package my.system;

import my.sensor.*;
import my.motor.*;
import my.thinker.*;
import my.surroundings.*;

/**
 * RecogSystem :+ Sensor, Motor, Thinker    // �ý����� ����, �, ������ ������.
 * RecogSystem -- Surroundings                // �ý����� ���� ȯ�濡 ����ȴ�.
 * 
 * 
 * @author hyosun.lee
 *
 */
public class RecogSystem {
	private Sensor sensor;
	private Sensor1 sensor1;
	private Motor motor;
	private Recognizer recognizer;
	private Thinker thinker;

	public Surroundings surroundings;
	
	public RecogSystem() {
		sensor = new Sensor();
		sensor1 = new Sensor1();
		motor = new Motor();
		recognizer = new Recognizer();
		thinker = new Thinker();
		
		sensor.setContact(recognizer);
		sensor1.setContact(recognizer);
		
		recognizer.setContact(thinker);
	}
	
	public void connect(Surroundings s) {
		System.out.println("	RecogSystem.connect()");
		surroundings = s;
	}
	
	public void sense() {
		System.out.println("	RecogSystem.sense()");
		sensor.measure(surroundings.thing);
		sensor1.measure(surroundings.thing);
	}
	
	public void recognize() {
		System.out.println("	RecogSystem.recognize()");
		recognizer.recognize();
	}
	public void think() {
		System.out.println("	RecogSystem.think()");
		thinker.think();
	}
	
	public void act() {
		System.out.println("	RecogSystem.act()");
		motor.act();
	}
}
