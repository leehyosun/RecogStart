import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;

public class JavaExtractPublic {
	private ArrayList<String> mLineList = new ArrayList<String>();
	private ArrayList<String> mResultList = new ArrayList<String>();
	
	public void parseFile(String filename) {
		readTextFromFile(filename);
		analysisText();
		//printResult();
	}
	
	public void printResult() {
		for (String str : mResultList) {
			System.out.println(str);
		}
	}
	
	public void printResultToFile(String outfilename) {
		File file = new File(outfilename);
		FileWriter fw = null;
		
		try {
			fw = new FileWriter(file);
			for (String str : mResultList) {
				fw.write(str);
				fw.write("\n");
				fw.flush();
			}
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * http://androidxref.com/5.0.0_r2/xref/prebuilts/sdk/api/21.txt
	 * 21.txt ���� package, class, interface �� ������ ������ �����Ѵ�.
	 */
	public void readTextFromFile(String filename) {
		Path fp1 = Paths.get(filename);
		File file1 = new File(fp1.toString());	
		String line;
		
		try {		
			BufferedReader br = new BufferedReader(new FileReader(file1));
			while ((line = br.readLine()) != null) {
				if (line.contains("package ") || line.contains(" class ") || line.contains(" interface ")){
					//System.out.println(line);
					mLineList.add(line);
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * package, class, interface ���� �����ϱ� ���ؼ� token���� �и��Ѵ�.
	 */
	public void analysisText() {
		Iterator<String> x = mLineList.listIterator();
		String line = null;
		String packageName = "";
		String className = "";
		String interfaceName = "";
		
		while (x.hasNext()) {
			line = x.next();
			if (line.contains("package")) {
				int begin = line.indexOf("package");
				int end = line.indexOf(" ", begin+8); 
				packageName = line.substring(begin+8, end);
			}
			else if (line.contains("class")) {
				int begin = line.indexOf("class");
				int end = line.indexOf(" ", begin+6); 
				className = line.substring(begin+6, end);
				mResultList.add("[" + packageName + "][" + className + "]");
			}
			else if (line.contains("interface")) {
				int begin = line.indexOf("interface");
				int end = line.indexOf(" ", begin+10); 
				interfaceName = line.substring(begin+10, end);
				mResultList.add("[" + packageName + "][" + interfaceName + "]");
			}
			
		}
	}

}
