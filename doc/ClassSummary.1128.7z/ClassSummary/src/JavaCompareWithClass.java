import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class JavaCompareWithClass {
	private ArrayList<String> mListA = new ArrayList<String>();
	private ArrayList<String> mListB = new ArrayList<String>();
	private ArrayList<String> mListA_B = new ArrayList<String>();
	
	public void compareMinus(String f1, String f2) {
		loadFileData(f1, f2);

		for (String astr : mListA) {
			for (String bstr : mListB) {
				if (astr.contains(bstr)) {
					mListA_B.add(astr);
					break;
				}
			}
		}
		
		printResult();
	}
	
	private void loadFileData(String f1, String f2) {
		Path fp1 = Paths.get(f1);
		Path fp2 = Paths.get(f2);
		File file1 = new File(fp1.toString());
		File file2 = new File(fp2.toString());
		
		String line;
		try {		
			BufferedReader br = new BufferedReader(new FileReader(file1));
			while ((line = br.readLine()) != null) {
				mListA.add(line);
			}
			br.close();
			
			br = new BufferedReader(new FileReader(file2));
			while ((line = br.readLine()) != null) {
				mListB.add(line);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void printResult() {
		for (String str : mListA_B) {
			System.out.println(str);
		}
	}
	
	public void printResultToFile(String outfilename) {
		File file = new File(outfilename);
		FileWriter fw = null;
		
		try {
			fw = new FileWriter(file);
			for (String str : mListA_B) {
				fw.write(str);
				fw.write("\n");
				fw.flush();
			}
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
