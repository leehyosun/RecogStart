package arori.util;

public class PrintArray {
	public void print(int[][] arr) {
		int xlen = arr.length;
		int ylen = arr[0].length;
		
		for (int x=0; x<xlen; x++) {
		    for (int y=0; y<ylen-1; y++) {
		    	System.out.print(arr[x][y] + " ");
		    }
		    System.out.println(arr[x][ylen-1]);
		}
	}
}
