package arori.util;


import java.util.ArrayList;

public class Debug {
	private String header = ".";
	private boolean enable = true;
	private boolean once = false;
	
	public void on() {
		enable = true;
	}
	
	public void off() {
		enable = false;
	}
	
	// �� ���� ����Ʈ �ϰ� ���� �� ���
	public void once() {
		enable = true;
		once = true;
	}
	
	private void onceoff() {
		if (once) {
			once = false;
			enable = false;
		}
	}
	
	public void p(String tag) {
		if (enable) {
			System.out.println(header + tag);
			onceoff();
		}
	}
	public void p(String tag, String s) {
		if (enable) {
			System.out.println(header + tag + "=" + s);
			onceoff();
		}
	}
	
	public void p(String tag, char c) {
		if (enable) {
			System.out.println(header + tag + "=" + c);
			onceoff();
		}
	}
	
	public void p(String tag, char[] s) {
		if (enable) {
			System.out.print(header + tag + "=");
			for (int i=0; i<s.length; i++)
				System.out.print(s[i]);
			
			System.out.println();
			onceoff();
		}
	}
	
	public void p(String tag, int a) {
		if (enable) {
			System.out.println(header + tag + "=" + a);
			onceoff();
		}
	}

	public void p(String tag, double a) {
		if (enable) {
			System.out.println(header + tag + "=" + a);
			onceoff();
		}
	}
	
	public void p(String tag, int a, int b) {
		if (enable) {
			System.out.println(header + tag + "=" + a + "," + b);
			onceoff();
		}
	}

	public void p(String tag, int a, int b, int c) {
		if (enable) {
			System.out.println(header + tag + "=" + a + "," + b + "," + c);
			onceoff();
		}
	}

	public void p(String tag, int a, int b, int c, int d) {
		if (enable) {
			System.out.println(header + tag + "=" + a + "," + b + "," + c + "," + d);
			onceoff();
		}
	}
	
	public void p(String tag, int[] arr) {
		if (enable) {
			System.out.println(header + tag + "----------------------");
			for (int i=0; i<arr.length; i++) {
				System.out.print(arr[i] + " ");
			}
			System.out.println();
			System.out.println(header + "----------------------");
			onceoff();
		}
	}
	
	public void p(String tag, int[][] arr) {
		if (enable) {
			System.out.println(header + tag + "----------------------");
			for (int i=0; i<arr.length; i++) {
				for (int j=0; j<arr[0].length; j++) {
					System.out.print(arr[i][j] + " ");
				}
				System.out.println();
			}
			System.out.println(header + "----------------------");
			onceoff();
		}
	}
	
	public void p(String tag, long[][] arr) {
		if (enable) {
			System.out.println(header + tag + "----------------------");
			for (int i=0; i<arr.length; i++) {
				for (int j=0; j<arr[0].length; j++) {
					System.out.print(arr[i][j] + " ");
				}
				System.out.println();
			}
			System.out.println(header + "----------------------");
			onceoff();
		}
	}
	
	public void p(String tag, float[][] arr) {
		if (enable) {
			System.out.println(header + tag + "----------------------");
			for (int i=0; i<arr.length; i++) {
				for (int j=0; j<arr[0].length; j++) {
					System.out.print(arr[i][j] + " ");
				}
				System.out.println();
			}
			System.out.println(header + "----------------------");
			onceoff();
		}
	}
	
	public void p(String tag, ArrayList<char[]> arr, char[] type) {
		if (enable) {
			System.out.println(header + tag + "----------------------");
			for (char[] a : arr) {
				for (int i=0; i<a.length; i++) {
					System.out.print(a[i] + " ");
				}
				System.out.println();
			}
			System.out.println(header + "----------------------");
			onceoff();
		}
	}
	
	public void p(String tag, ArrayList<Integer> arr, Integer type) {
		if (enable) {
			System.out.println(header + tag + "----------------------");
			for (Integer a : arr) {
				System.out.print(a + " ");
			}
			System.out.println();
			System.out.println(header + "----------------------");
			onceoff();
		}
	}
	
	public void p(String tag, ArrayList<Object> arr, Object type) {
		if (enable) {
			System.out.println(header + tag + "----------------------");
			for (Object a : arr) {
				System.out.print(a + " ");
			}
			System.out.println();
			System.out.println(header + "----------------------");
			onceoff();
		}
	}
	
}
