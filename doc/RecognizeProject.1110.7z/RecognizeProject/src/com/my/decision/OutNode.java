package com.my.decision;

public class OutNode {
	
	private String mValue;
	
	/*
	 * OutNode Node�� Ȱ��ȭ �Ǿ������� ��Ÿ���� value �� (�� / ����)
	 */
	private boolean mActivated = false;
	
	public OutNode (String v) {
		mValue = v;
	}
	
	public OutNode(String v, Boolean b) {
		mValue = v;
		mActivated = b;
	}
	
	public String getName() {
		return mValue;
	}
	
	public void activate() {
		mActivated = true;
	}
	
	public boolean isActivated() {
		return mActivated;
	}
	
	public void reset() {
		mActivated = false;
	}
	
	public void print() {
		System.out.println("mActivated=" + mActivated);
		System.out.println("OutNode = " + mValue);
	}
}
