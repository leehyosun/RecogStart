package com.my.decision;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import com.my.dictionary.InputStringDictionary;

public class RecogDB {
	
	String RECOGFILENAME = "RecogDB.txt";
	String RECOGFILENAME_OUT = "RecogDB_out.txt";
	
	private static RecogDB mInstance = new RecogDB();
	
	private RecogDB() {
	}
	
    public static RecogDB getInstance() {
        return mInstance;
    }
    
	/*
	 * ���ᱸ�� ���Ϸκ��� DB�� �о� �޸� RootNode �� �����.
	 */
    
    public RootNode loadRecogDB_outdb() {
    	RECOGFILENAME = RECOGFILENAME_OUT;
    	return loadRecogDB();
    }
    
	public RootNode loadRecogDB() {
		System.out.println("[log] RecogDB.loadRecogDB()");
		
		RootNode node = new RootNode();
		ArrayList<InNode> inNodeList = new ArrayList<InNode>();
		ArrayList<OutNode> outNodeList = new ArrayList<OutNode>();
		ArrayList<ConNode> conNodeList = new ArrayList<ConNode>();
		
		node.setNodeList(inNodeList, conNodeList, outNodeList);
		
		int inCount = 0;
		int outCount = 0;
		int conCount = 0;
		int relCount = 0;
		
		String filename = System.getProperty("user.dir")+"\\data\\" + RECOGFILENAME;
		
		// 
		
		// ���� �б�
		FileReader fr = null;
		try {
		    fr = new FileReader(filename);
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		}
		BufferedReader br = new BufferedReader(fr);
		
		// ��ǲ, �ƿ�ǲ, ���� ���, ���� ���� �б�
		StringTokenizer tokenizer = null;
		try {
			String str = br.readLine();
			if (!str.isEmpty()) {
				tokenizer = new StringTokenizer(str);
				
				if (tokenizer.hasMoreTokens())
					inCount = Byte.parseByte(tokenizer.nextToken());
				
				if (tokenizer.hasMoreTokens())
					outCount = Byte.parseByte(tokenizer.nextToken());
				
				if (tokenizer.hasMoreTokens())
					conCount = Byte.parseByte(tokenizer.nextToken());
				
				if (tokenizer.hasMoreTokens())
					relCount = Byte.parseByte(tokenizer.nextToken());
				
				System.out.println("inCount=" + inCount);
				System.out.println("outCount=" + outCount);
				System.out.println("conCount=" + conCount);
				System.out.println("relCount=" + relCount);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// ��ǲ �б�
		try {
			for (int i=0; i < inCount; i++) {
				String str = br.readLine();
				System.out.println("InNode=" + str);
				inNodeList.add(new InNode(str));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// �ƿ�ǲ �б�
		try {
			for (int i=0; i < outCount; i++) {
				String str = br.readLine();
				System.out.println("OutNode=" + str);
				outNodeList.add(new OutNode(str));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		// ���� ���
		try {
			for (int i=0; i < conCount; i++) {
				String str = br.readLine();
				System.out.println("ConNode=" + str);
				conNodeList.add(new ConNode(str));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("-------------------");
		
		// ���� �����
		try {
			for (int i=0; i < relCount; i++) {
				String str = br.readLine();
				String type = "";
				String from = "";
				String to = "";
				
				System.out.println("str1=" + str);
				
				if (!str.isEmpty()) {
					tokenizer = new StringTokenizer(str);
					
					if (tokenizer.hasMoreTokens())
						type = tokenizer.nextToken();
					
					if (tokenizer.hasMoreTokens())
						from = tokenizer.nextToken();
					
					if (tokenizer.hasMoreTokens())
						to = tokenizer.nextToken();
				}

				System.out.println("type=" + type + " from=" + from + " to=" + to);
				
				if (type.equals("IC")) {
					InNode fromNode = null;
					ConNode toNode = null;
					
					for (InNode o : inNodeList) {
						if (o.getName().equals(from)) {
							fromNode = o;
						}
					}
					
					for (ConNode o : conNodeList) {
						if (o.getName().equals(to)) {
							toNode = o;
						}
					}

					fromNode.addConNode(toNode);
				}

				if (type.equals("CI")) {
					ConNode fromNode = null;
					InNode toNode = null;
					
					for (ConNode o : conNodeList) {
						if (o.getName().equals(from)) {
							fromNode = o;
						}
					}
					
					for (InNode o : inNodeList) {
						if (o.getName().equals(to)) {
							toNode = o;
						}
					}

					fromNode.addInNode(toNode);
				}
				
				if (type.equals("CO")) {
					ConNode fromNode = null;
					OutNode toNode = null;
					
					for (ConNode o : conNodeList) {
						if (o.getName().equals(from)) {
							fromNode = o;
						}
					}
					
					for (OutNode o : outNodeList) {
						if (o.getName().equals(to)) {
							toNode = o;
						}
					}

					fromNode.addOutNode(toNode);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("------------- test ------------");
		
		// test
		for (InNode o : inNodeList) {
			System.out.println("o.getName=" + o.getName());
		}
		
		for (OutNode o : outNodeList) {
			System.out.println("o.getName=" + o.getName());
		}
		
		for (ConNode o : conNodeList) {
			System.out.println("o.getName=" + o.getName());
		}
		
		try {
		    br.close();
		    fr.close();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		return node;
	}
	
	/*
	 * �޸� RootNode �� ������ ���ᱸ�� ���� DB�� �����Ѵ�.
	 */
	public void saveRecogDB(RootNode root) {
		System.out.println("[log] RecogDB.saveRecogDB()");
		
		ArrayList<InNode> inNodeList = root.getInNodeList();
		ArrayList<OutNode> outNodeList = root.getOutNodeList();
		ArrayList<ConNode> conNodeList = root.getConNodeList();
		
		String filename = System.getProperty("user.dir")+"\\data\\" + RECOGFILENAME_OUT;
		
		FileWriter fw = null;
		try {
		    fw = new FileWriter(filename);
		
		    BufferedWriter bw = new BufferedWriter(fw);
		    
		    // ���� �Է�
		    int cntInNode = inNodeList.size();
			bw.write(cntInNode + " ");

		    int cntOutNode = outNodeList.size();
			bw.write(cntOutNode + " ");

		    int cntConNode = conNodeList.size();
			bw.write(cntConNode + " ");
			
			int cntRel = 0;
			for (InNode o : inNodeList) {
				cntRel += o.getConNodeListCount();
			}
			for (ConNode o : conNodeList) {
				cntRel += o.getInNodeListCount() + o.getOutNodeListCount();
			}
			
			System.out.println("cntRel=" + cntRel);
			bw.write(cntRel + "\n");
			
			// ��� ����
			for (InNode o : inNodeList) {
				System.out.println("o.getName()=" + o.getName());
				bw.write(o.getName() + "\n");
			}
			
			for (OutNode o : outNodeList) {
				System.out.println("o.getName()=" + o.getName());
				bw.write(o.getName() + "\n");
			}
			
			for (ConNode o : conNodeList) {
				System.out.println("o.getName()=" + o.getName());
				bw.write(o.getName() + "\n");
			}
			
			// ���� ����
			for (InNode in : inNodeList) {
				for (ConNode con : conNodeList) {
					bw.write("IC " + in.getName() + " " + con.getName() + "\n");
				}
			}
			
			for (ConNode con : conNodeList) {
				for (InNode in : inNodeList) {
					bw.write("CI " + con.getName() + " " + in.getName() + "\n");
				}
				
				for (OutNode out : outNodeList) {
					bw.write("CO " + con.getName() + " " + out.getName() + "\n");
				}
			}
			
		    bw.close();
		    fw.close();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
	}
}
