package com.my.decision;
import com.my.decision.*;

/**
 * �ǻ� �����ϱ�
 * @author hyosun.lee
 *
 */
public class DecisionMaking {
	
	RootNode node = new RootNode();
	
	public void decide() {
		System.out.println("[log] DecisionMaking.decide()");
	}
	
	public void testDecisionBasic() {
		System.out.println("[log] DecisionMaking.test()");
		
		node.setSampleData();
		node.doDecision();
	}
	
	public void testDecisionBasic2() {
		System.out.println("[log] DecisionMaking.test() 2");
		
		node.setSampleData2();
		node.doDecision();
	}
}
