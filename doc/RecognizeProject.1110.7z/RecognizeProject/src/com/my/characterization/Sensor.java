package com.my.characterization;

import java.util.ArrayList;

import com.my.dictionary.InputDictionary;
import com.my.dictionary.OutputDictionary;

public class Sensor extends SensorBase {
	
	static int [][] mArr;
	
	private ArrayList<Svalue> mSvalueList = new ArrayList<Svalue>();
	
	// Sensor�� �����ϱ� ���� �����͸� �ε��Ѵ�.
	public void loadData(int [][] arr) {
		mArr = arr;
	}
	
	// ���� �ʱ� ����
	public void setupSensor() {
		
	}
	
	// ������ �ִ� ����Ÿ�� ����Ͽ� Ư¡�� �����Ѵ�.
	@Override
	public void extractFeature() {
		specifyHorizontal();
		specifyVertial();

		updateDictionary();
	}
	
	public void print() {
		System.out.println("[log] CombPattern.print()");
	}

	// ������ �������� Ư¡�� �ϳ� �ϳ��� �Լ��� �����ȴ�.
	private void specifyHorizontal() {
		String name = "CombH";
		Svalue svalue = new Svalue();
		svalue.mName = name;

		for (int n=0; n<3; n++) {
			boolean check = false;
			for (int i=0; i<3; i++) {
				if (mArr[n][i] != 0) {
					System.out.println("(" + n + "," + i + ")=" + mArr[n][i]);
					check = true;
				}
			}
			
			if (check == true) {
				svalue.mElementArr[n] = 1;
			}
			

			System.out.println("specifyHorizontal() n[" + n  + "]=" + svalue.mElementArr[n]);
		}
		
		mSvalueList.add(svalue);
	}
	
	private void specifyVertial() {
		String name = "V";
		Svalue svalue = new Svalue();
		svalue.mName = name;

		for (int n=0; n<3; n++) {
			boolean check = false;
			for (int i=0; i<3; i++) {
				if (mArr[i][n] != 0) {
					System.out.println("(" + i + "," + n + ")=" + mArr[i][n]);
					check = true;
				}
			}
			
			if (check == true) {
				svalue.mElementArr[n] = 1;
			}

			System.out.println("specifyVertial() n[" + n  + "]=" + svalue.mElementArr[n]);
		}
		
		mSvalueList.add(svalue);
	}

	@Override
	void updateDictionary() {
		// TODO Auto-generated method stub
		
		InputDictionary inDict = InputDictionary.getInstance();
		
		for (Svalue o : mSvalueList) {
			if (o.mName.equals("H")) {
				if (o.mElementArr[0] == 0)
					inDict.add(1001, Boolean.valueOf(false));
				else
					inDict.add(1001, Boolean.valueOf(true));
				
				if (o.mElementArr[1] == 0)
					inDict.add(1002, Boolean.valueOf(false));
				else
					inDict.add(1002, Boolean.valueOf(true));
				
				if (o.mElementArr[2] == 0)
					inDict.add(1003, Boolean.valueOf(false));
				else
					inDict.add(1003, Boolean.valueOf(true));
			}
			
			if (o.mName.equals("V")) {
				if (o.mElementArr[0] == 0)
					inDict.add(2001, Boolean.valueOf(false));
				else
					inDict.add(2001, Boolean.valueOf(true));
				
				if (o.mElementArr[1] == 0)
					inDict.add(2002, Boolean.valueOf(false));
				else
					inDict.add(2002, Boolean.valueOf(true));
				
				if (o.mElementArr[2] == 0)
					inDict.add(2003, Boolean.valueOf(false));
				else
					inDict.add(2003, Boolean.valueOf(true));
			}
		}
	}
}
