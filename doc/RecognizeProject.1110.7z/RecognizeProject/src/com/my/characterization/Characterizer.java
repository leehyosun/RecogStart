package com.my.characterization;
import java.util.ArrayList;

import com.my.Image.ImageData;
import com.my.dictionary.InputStringDictionary;
import com.my.dictionary.OutputStringDictionary;

/**
 * Ư¡ �����ϱ�
 *
 * 1. �̹��� �����͸� �о� ���δ�.
 * 2. Ư¡�� �����Ѵ�.
 * 3. Ư¡ �����͸� ����Ѵ�.
 * 
 * @author hyosun.lee
 */
public class Characterizer {
	int [][] mArr;
	
	ArrayList<ImageData> mImageDataList = new ArrayList<ImageData>();
	ArrayList<SensorBase> mSensorList = new ArrayList<SensorBase>();
	
	Sensor sensor = new Sensor();
	
	// extract_next
	SensorH0 sensor_h0 = new SensorH0();
	SensorH1 sensor_h1 = new SensorH1();
	SensorH2 sensor_h2 = new SensorH2();
	
	public void loadArray(int [][] arr) {
		mArr = arr;
	}

	public void setupSensor() {
		mSensorList.add(sensor_h0);
		mSensorList.add(sensor_h1);
		mSensorList.add(sensor_h2);
	}
	
	public void extractFromArray() {
		sensor.loadData(mArr);
		sensor.extractFeature();
		printArray(mArr);
	}
	
	public void loadImageDataList(ArrayList<ImageData> d) {
		mImageDataList = d;
	}
	
	/*
	 * �������� ������ ����Ͽ� Ư¡�� �����Ѵ�.
	 * 
	 * �̹��� �����͵�κ��� Ư¡ ����⸦ ������ Ư¡�� ������ ����,
	 * unique id�� �ο��Ѵ�.
	 */
	public void extract() {
		int [][] arr;
		
		System.out.println("[log] Characterizer.extract() 1");
		System.out.println("size()=" + mImageDataList.size());
		
		for (ImageData o : mImageDataList) {
			arr = o.getData();
			sensor.loadData(arr);
			sensor.extractFeature();
			//printArray(arr);
		}
	}
	
	public void extract_next() {
		int [][] arr;
		
		System.out.println("[log] Characterizer.extract_next()");
		System.out.println("size()=" + mImageDataList.size());
		
		Surrounding surrounding = Surrounding.getInstance();

		for (ImageData o : mImageDataList) {
			arr = o.getData();
			surrounding.loadData(arr);
			
			System.out.println("mSensorList.size()=" + mSensorList.size());
			
			for (SensorBase sb : mSensorList) {
				sb.extractFeature();
			}
			
			for (SensorBase sb : mSensorList) {
				sb.updateDictionary();
			}
			
			InputStringDictionary inDict = InputStringDictionary.getInstance();
			inDict.print();
			
			OutputStringDictionary outDict = OutputStringDictionary.getInstance();
			
			outDict.add(o.getChar(), true);
			outDict.print();
		}

	}

	private void printArray(int[][] arr) {
		for (int i=0; i<arr.length; i++) {
			for (int j=0; j<arr[0].length; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}
	}

	/*
	public void print() {
		for (int i=0; i<mArr.length; i++) {
			for (int j=0; j<mArr[0].length; j++) {
				System.out.print(mArr[i][j] + " ");
			}
			System.out.println();
		}
	}
	 */
}
