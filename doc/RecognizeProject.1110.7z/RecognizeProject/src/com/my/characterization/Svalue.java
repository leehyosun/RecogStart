package com.my.characterization;

public class Svalue {
	String mName;
	int mValue;
	int [] mElementArr = new int[3];
}
