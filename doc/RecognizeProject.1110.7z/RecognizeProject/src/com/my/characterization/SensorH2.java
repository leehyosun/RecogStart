package com.my.characterization;

import com.my.dictionary.InputStringDictionary;

public class SensorH2 extends SensorBase {
	static String name = "SensorH2";
	boolean check = false;
	
	@Override
	void extractFeature() {
		// TODO Auto-generated method stub
		Surrounding surround = Surrounding.getInstance();

		// �� ������ ù��° �ٺ��� ���η� ���� 1�� ������ true
		for (int i=0; i<3; i++) {
			if (surround.mArr[2][i] != 0) {
				System.out.println("SensorH2=" + surround.mArr[0][i]);
				check = true;
			}
		}

		System.out.println("SensorH2=" + check);
	}

	@Override
	void updateDictionary() {
		// TODO Auto-generated method stub
		InputStringDictionary inDict = InputStringDictionary.getInstance();
		
		inDict.add(name, check);
	}

}
