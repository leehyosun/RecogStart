package com.my.Image;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import arori.util.PrintArray;

import com.my.Image.*;

/**
 * ���� �̹��� ���� Ŭ����
 * 
 * @author hyosun.lee
 *
 */
public class ImageDataManager {
	
	ArrayList<ImageData> mImageDataList = new ArrayList<ImageData>();
	
	public ImageDataManager() {
		
	}
	
	public ArrayList<ImageData> getImageDataList() {
		return mImageDataList;
	}
	
	// ����Ÿ �����ϱ�
	// ex) > 1 �� -> 1
	public void refineDataFile() {
		System.out.println("[log] ImageDataManager.refineDataFile()");
		for (ImageData o : mImageDataList) {
			for (int i=0; i<3; i++) {
				for (int j=0; j<3; j++)
					if (o.mData[i][j] > 1)
						o.mData[i][j]= 1;
			}
		}
	}
	
	// ���Ϸκ��� ����Ÿ �б�
	public void loadDataFile(String filename) {
		System.out.println("[log] ImageDataManager.loadDataFile()");
		
		FileReader fr = null;
		try {
		    fr = new FileReader(filename);
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		}
		BufferedReader br = new BufferedReader(fr);
		
		int dbCount = 0;
		try {
			String dbCountString = br.readLine();
			if (!dbCountString.isEmpty())
				dbCount = Integer.parseInt(dbCountString);
			
			//System.out.println("dbCount=" + dbCount);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		for (int n=0; n<dbCount; n++) {
			ImageData data = new ImageData();
			
			try {
				data.mChar = br.readLine();
				//System.out.println("dbChar=" + data.mChar);
			} catch (IOException e) {
				e.printStackTrace();
			}
	
			StringTokenizer tokenizer = null;
			for (int i=0; i<data.ROW_LENGTH; i++) {
			    try {
			    	tokenizer = new StringTokenizer(br.readLine());
			    	int j=0;
			    	while (tokenizer.hasMoreTokens()) {
			    		data.mData[i][j] = Byte.parseByte(tokenizer.nextToken());
			    		j++;
			    	}
			    } catch (IOException e) {
			    	e.printStackTrace();
			    }
			}
			
			//PrintArray pr = new PrintArray();
			//pr.print(ie.mData);
			
			mImageDataList.add(data);
		}
		
		try {
		    br.close();
		    fr.close();
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	public void print() {
		PrintArray pr = new PrintArray();
		
		for (ImageData o : mImageDataList) {
			System.out.println(o.mChar);
			pr.print(o.mData);
		}
	}
}
