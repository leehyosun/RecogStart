package com.my.Image;

/**
 * �ϳ��� ���� �̹��� �����͸� �����ϴ� Ŭ����
 * 
 * @author hyosun.lee
 *
 */
public class ImageData {
	
	static int ROW_LENGTH = 3;
	static int COL_LENGTH = 3;
	
	int[][] mData; 
	String mChar;
	
	public ImageData() {
		mData = new int[ROW_LENGTH][COL_LENGTH];
	}
	
	public String getChar() {
		return mChar;
	}
	
	public int[][] getData() {
		return mData;
	}
	
	// ������ �ʱ�ȭ
	private void initData() {
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++)
				mData[i][j] = 0;
		}
	}
	
	private void print() {
		for (int i=0; i<3; i++) {
			for (int j=0; j<3; j++) {
				System.out.print(mData[i][j] + " ");
			}
			System.out.println();
		}
	}
}
