package com.my.dictionary;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.my.decision.InNode;
import com.my.decision.OutNode;
import com.my.decision.RecogDB;
import com.my.decision.RootNode;

public class OutputStringDictionary {
	
	// HashMap (Key, Value)
	HashMap<String, Boolean> mOutputMap = new HashMap<String, Boolean>();
	
	private static OutputStringDictionary mInstance = new OutputStringDictionary();
	
    public static OutputStringDictionary getInstance() {
        return mInstance;
    }
    
	public void add(String key, Boolean value) {
		mOutputMap.put(key, value);
	}
	
	public Boolean get(String key) {
		return mOutputMap.get(key);
	}
	
	public void updateRecogDB(RootNode root) {
		System.out.println("OutputStringDictionary.updateRecogDB()");
		
		ArrayList<OutNode> outNodeList = root.getOutNodeList();
		
		Set<Entry<String, Boolean>> set = mOutputMap.entrySet();
		Iterator<Entry<String, Boolean>> it = set.iterator();
		
		System.out.println("outNodeList.size=" + outNodeList.size());
		
		while (it.hasNext()) {
			Map.Entry<String, Boolean> e = (Map.Entry<String, Boolean>)it.next();
			System.out.println("Key=" + e.getKey() + ", Value=" + e.getValue());
			
			boolean found = false;
			for (OutNode out : outNodeList) {
				if (out.equals(e.getKey())) {
					found = true;
					if (e.getValue() ==  true) {
						out.activate();
					}
					else if (e.getValue() == false) {
						out.reset();
					}
				}
			}
			
			if (found == false) {
				outNodeList.add(new OutNode(e.getKey(), e.getValue()));
			}
		}
		
		System.out.println("--------");
		for (OutNode o : outNodeList) {
			System.out.println(": " + o.getName() + " " + o.isActivated());
		}
	}
	
	public void print() {
		System.out.println("OutputStringDictionary.print()");
		
		Set<Entry<String, Boolean>> set = mOutputMap.entrySet();
		Iterator<Entry<String, Boolean>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Boolean> e = (Map.Entry<String, Boolean>)it.next();
			System.out.println("Key=" + e.getKey() + ", Value=" + e.getValue());
		}
	}
}
