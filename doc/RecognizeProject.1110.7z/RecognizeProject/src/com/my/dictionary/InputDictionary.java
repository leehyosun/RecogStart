package com.my.dictionary;

import java.util.HashMap;

public class InputDictionary {
	
	// HashMap (Key, Value)
	HashMap<Integer, Boolean> mMap = new HashMap<Integer, Boolean>();
	
	private static InputDictionary mInstance = new InputDictionary();
	
    public static InputDictionary getInstance() {
        return mInstance;
    }
    
	public void add(Integer key, Boolean value) {
		mMap.put(key, value);
	}
	
	public void print() {
		
	}
}
