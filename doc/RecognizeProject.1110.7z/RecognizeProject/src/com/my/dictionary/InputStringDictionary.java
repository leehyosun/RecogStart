package com.my.dictionary;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.my.decision.InNode;
import com.my.decision.RecogDB;
import com.my.decision.RootNode;

public class InputStringDictionary {
	
	// HashMap (Key, Value)
	HashMap<String, Boolean> mInputMap = new HashMap<String, Boolean>();
	
	private static InputStringDictionary mInstance = new InputStringDictionary();
	
    public static InputStringDictionary getInstance() {
        return mInstance;
    }
    
	public void add(String key, Boolean value) {
		mInputMap.put(key, value);
	}
	
	public Boolean get(String key) {
		return mInputMap.get(key);
	}
	
	public void updateRecogDB(RootNode root) {
		System.out.println("InputStringDictionary.updateRecogDB()");
		
		ArrayList<InNode> inNodeList = root.getInNodeList();
		
		Set<Entry<String, Boolean>> set = mInputMap.entrySet();
		Iterator<Entry<String, Boolean>> it = set.iterator();
		
		System.out.println("inNodeList.size=" + inNodeList.size());
		
		while (it.hasNext()) {
			Map.Entry<String, Boolean> e = (Map.Entry<String, Boolean>)it.next();
			System.out.println("Key=" + e.getKey() + ", Value=" + e.getValue());
			
			boolean found = false;
			for (InNode in : inNodeList) {
				if (in.equals(e.getKey())) {
					found = true;
					if (e.getValue() ==  true) {
						in.activate();
					}
					else if (e.getValue() == false) {
						in.reset();
					}
				}
			}
			
			if (found == false) {
				inNodeList.add(new InNode(e.getKey(), e.getValue()));
			}
		}

		for (InNode o : inNodeList) {
			System.out.println(": " + o.getName() + " " + o.isActivated());
		}
	}
	
	public void print() {
		System.out.println("InputStringDictionary.print()");
		
		Set<Entry<String, Boolean>> set = mInputMap.entrySet();
		Iterator<Entry<String, Boolean>> it = set.iterator();
		
		while (it.hasNext()) {
			Map.Entry<String, Boolean> e = (Map.Entry<String, Boolean>)it.next();
			System.out.println("Key=" + e.getKey() + ", Value=" + e.getValue());
		}
	}
}
