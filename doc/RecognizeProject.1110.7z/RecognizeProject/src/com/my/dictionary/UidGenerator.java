package com.my.dictionary;

public class UidGenerator {
	private static Integer mIndex = 0;
	private static UidGenerator mInstance = new UidGenerator();
	
    public static UidGenerator getInstance() {
        return mInstance;
    }
    
    public Integer getUid() {
    	return mIndex++;
    }
}
