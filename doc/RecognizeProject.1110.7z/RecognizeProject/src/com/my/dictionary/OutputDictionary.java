package com.my.dictionary;

import java.util.HashMap;

public class OutputDictionary {
	
	// HashMap (Key, Value)
	HashMap<Integer, String> mOutputMap = new HashMap<Integer, String>();
	
	private static OutputDictionary mInstance = new OutputDictionary();
	
    public static OutputDictionary getInstance() {
        return mInstance;
    }
    
	public void add(Integer key, String value) {
		mOutputMap.put(key, value);
	}
	
	public String get(Integer key) {
		return mOutputMap.get(key);
	}
	
	
}
