import com.my.Image.ImageData;
import com.my.Image.ImageDataManager;
import com.my.characterization.Characterizer;
import com.my.decision.DecisionMaking;
import com.my.dictionary.InputDictionary;
import com.my.dictionary.OutputDictionary;
import com.my.dictionary.UidGenerator;
import com.my.learning.Learning;

public class LetterRecognizer {
	public static void main(String[] args) {
		System.out.println("[log] ObjectRecognizer.main()");
	
		//doProcess();
		
		doImageLoad();
		
		//doDictionary();
	}
	
	/*
	 * ���߱�
	 * 
	 * 1) �̹��� ���� �Ǵ� �迭 �ؽ�Ʈ�� ����
	 * 2) ���ڷ� 
	 * 
	 */
	public static void doProcess() {
		System.out.println("[log] ObjectRecognizer.doProcess()");
		
		// �̹��� ������
		ImageData imagedata = new ImageData();
		
		// �̹��� �ٵ��
		Refinery refinery = new Refinery();
		
		// Ư¡ �����ϱ�
		Characterizer characterizer = new Characterizer();
		
		// �ǻ� �����ϱ�
		DecisionMaking decision = new DecisionMaking();
		
		// ��� ������
		OutputData out = new OutputData();
		
		
		// ó��
		//imagedata.load();
		//refinery.getData(imagedata.mData);
		refinery.refine();
		characterizer.loadArray(refinery.mArr);
		characterizer.extractFromArray();
		//characterizer.print();
		
		decision.decide();
		decision.testDecisionBasic();
		out.print();
	}
	
	public static void doImageLoad() {
		ImageDataManager manager = new ImageDataManager();
		String filename = System.getProperty("user.dir")+"\\data\\learning_data.txt";
		
		manager.loadDataFile(filename);
		//imagedata.print();
		
		// Ư¡ �����ϱ�
		Characterizer characterizer = new Characterizer();
		
		characterizer.loadImageDataList(manager.getImageDataList());
		characterizer.extract();
		
	}
	
	public static void doDictionary() {
		UidGenerator uidGen = UidGenerator.getInstance();
		InputDictionary inDict = InputDictionary.getInstance();
		OutputDictionary outDict = OutputDictionary.getInstance();
		
		inDict.add(uidGen.getUid(), Boolean.valueOf(true));
		inDict.add(uidGen.getUid(), Boolean.valueOf(false));
		
		outDict.add(uidGen.getUid(), String.valueOf("A"));
		outDict.add(uidGen.getUid(), String.valueOf("B"));
		
		System.out.println(outDict.toString());
	}
}
