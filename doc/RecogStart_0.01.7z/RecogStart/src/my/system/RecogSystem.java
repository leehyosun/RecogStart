package my.system;

import my.sensor.*;
import my.motor.*;
import my.thinker.*;
import my.surroundings.*;

/**
 * RecogSystem :+ Sensor, Motor, Thinker    // �ý����� ����, �, ������ ������.
 * RecogSystem -- Surroundings                // �ý����� ���� ȯ�濡 ����ȴ�.
 * 
 * 
 * @author hyosun.lee
 *
 */
public class RecogSystem {
	private Sensor sensor;
	private Motor motor;
	private Thinker thinker;
	
	public Surroundings surroundings;
	
	public RecogSystem() {
		sensor = new Sensor();
		motor = new Motor();
		thinker = new Thinker();
		
		sensor.setContact(thinker);
	}
	
	public void connect(Surroundings s) {
		System.out.println("	RecogSystem.connect()");
		surroundings = s;
	}
	
	public void sense() {
		System.out.println("	RecogSystem.sense()");
		sensor.measure(surroundings.thing);
	}
	
	public void think() {
		System.out.println("	RecogSystem.think()");
		thinker.think();
	}
	
	public void act() {
		System.out.println("	RecogSystem.act()");
		motor.act();
	}
}
