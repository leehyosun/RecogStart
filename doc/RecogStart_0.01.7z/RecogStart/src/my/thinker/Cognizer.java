package my.thinker;

public class Cognizer {

}
