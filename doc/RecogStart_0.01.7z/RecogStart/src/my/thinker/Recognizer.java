package my.thinker;

public class Recognizer {

}
