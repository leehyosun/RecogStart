package my.thinker;

public class Learner {

}
