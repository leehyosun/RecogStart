

public class Main {
	public static void main(String[] args) {
		if (args.length < 2) {
			System.out.println("usage: -f [filename] | -d [directory name] -o [output filename]");
			System.out.println("usage: -f1 [filename] -f2 [filename]");
			return;
		}
		
		JavaParser jp = new JavaParser();
		
		if (args[0].equals("-f")) {
			String filename = args[1];
			jp.parseFile(filename);
		}
		
		if (args[0].equals("-d")) {
			String dirname = args[1];
			jp.parseDir(dirname);
		}
		
		if (args[2].equals("-o")) {
			String outfilename = args[3];
			jp.printResultToFile(outfilename);
		}
		
		JavaCompare jc = new JavaCompare();
		String f1 = "";
		String f2 = "";
		
		if (args[0].equals("-f1")) {
			f1 = args[1];
		}
		
		if (args[2].equals("-f2")) {
			f2 = args[3];
		}
		
		jc.compareMinus(f1, f2);
	}
}
