import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;


public class JavaParser {
	private static final String WHITESPACE_AND_QUOTES = " \t\r\n\"{}()=;";
	private String mFileText;
	private ArrayList<String> mParsedList = new ArrayList<String>();
	private ArrayList<String> mResultList = new ArrayList<String>();
	private ArrayList<String> mFileList = new ArrayList<String>();

	public void parseFile(String filename) {
		readTextFromFile(filename);
		parseText();
		analysisText();
		mParsedList.clear();
	}
	
	public void parseDir(String dirname) {
		subDirList(dirname);
		for (String str : mFileList) {
			parseFile(str);
		}
		//printAllFiles();
	}
	
	public void printResult() {
		for (String str : mResultList) {
			System.out.println(str);
		}
	}
	
	public void printResultToFile(String outfilename) {
		File file = new File(outfilename);
		FileWriter fw = null;
		
		try {
			fw = new FileWriter(file);
			for (String str : mResultList) {
				fw.write(str);
				fw.write("\n");
				fw.flush();
			}
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void printAllFiles() {
		for (String st : mFileList) {
			System.out.println(st);
		}
	}
	
	public void analysisText() {
		Iterator<String> x = mParsedList.listIterator();
		
		String str = null;
		String outstr = "";
		String curpkg = "";
		String curcls = "";
		Boolean outflag = false;
		Boolean pkgflag = false;
		Boolean clsflag = false;
		
		while (x.hasNext()) {
			str = x.next();
			if (str.equals("package")) {
				pkgflag = true;
			}
			
			if (str.equals("class")) {
				clsflag = true;
			}
			
			if (str.equals("public") || str.equals("protected") || str.equals("private")) {
				outflag = true;
			}

			if (pkgflag && str.equals(";")) {
				if (outstr.length() > 8) {
					curpkg = outstr.substring(8, outstr.length()-1);
					mResultList.add(outstr);
				}
				pkgflag = false;
				outstr = "";
			}
			
			if (pkgflag && str.equals("\"")) {
				pkgflag = false;
				outstr = "";
			}
			
			if (clsflag && str.equals("{")) {
				int a = outstr.indexOf("class")+6;
				int b = outstr.indexOf(" ", a);
				curcls = outstr.substring(a, b);
				
				StringBuffer strBuf = new StringBuffer();
				strBuf.append("[");
				strBuf.append(curpkg);
				strBuf.append("]");
				strBuf.append(outstr);
				mResultList.add(strBuf.toString());
				clsflag = false;
				outstr = "";
			}
			else if (outflag && str.equals("{")) {
				StringBuffer strBuf = new StringBuffer();
				strBuf.append("[");
				strBuf.append(curpkg);
				strBuf.append("][");
				strBuf.append(curcls);
				strBuf.append("]");
				strBuf.append(outstr);
				mResultList.add(strBuf.toString());
				outflag = false;
				outstr = "";
			}
			
			if (outflag && str.equals(";")) {
				outflag = false;
				outstr = "";
			}
			
			if (outflag && str.equals("=")) {
				outflag = false;
				outstr = "";
			}
			
			if (outflag || pkgflag || clsflag) {
				outstr += str + " ";
			}
		}

	}
	
	public void readTextFromFile(String filename) {
		Path filePath = Paths.get(filename);
		//System.out.println(filePath);
	
		File file = new File(filePath.toString());
		FileReader fr = null;
		int i = 0;
		StringBuffer strBuf = new StringBuffer();
		
		try {
			fr = new FileReader(file);
			while ((i=fr.read()) != -1) {
				strBuf.append((char)i);
			}
			mFileText = strBuf.toString();
			//System.out.println(mFileText);
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void parseText() {
		String currentDelims = WHITESPACE_AND_QUOTES;
		StringTokenizer parser = new StringTokenizer(mFileText, currentDelims, true);
		
		String token = null;
		while (parser.hasMoreTokens()) {
			token = parser.nextToken(currentDelims);
			if (token.trim().length() > 0) {
				//System.out.println(token.toString());
				mParsedList.add(token.trim());
			}
		}
	}
	
	public void subDirList(String source) {
		File dir = new File(source);
		File[] fileList = dir.listFiles();
		
		try{
			for(int i = 0 ; i < fileList.length ; i++){
				File file = fileList[i]; 
				if(file.isFile()){
					mFileList.add(file.getCanonicalPath());
				}else if(file.isDirectory()){
					subDirList(file.getCanonicalPath().toString()); 
				}
			}
		}catch(IOException e){
		}
	}
}
