import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;


public class JavaCompare {
	private ArrayList<String> mListA = new ArrayList<String>();
	private ArrayList<String> mListB = new ArrayList<String>();
	private ArrayList<String> mListA_B = new ArrayList<String>();
	
	public void compareMinus(String f1, String f2) {
		loadFileData(f1, f2);
		//printFileData();

		Boolean found = false;
		
		for (String astr : mListA) {
			found = false;
			for (String bstr : mListB) {
				if (bstr.equals(astr)) {
					found = true;
					break;
				}
			}
			if (found == false) {
				mListA_B.add(astr);
			}
		}
		
		printResult();
	}
	
	private void printResult() {
		for (String str : mListA_B) {
			System.out.println(str);
		}
	}
	
	private void loadFileData(String f1, String f2) {
		Path fp1 = Paths.get(f1);
		Path fp2 = Paths.get(f2);
		File file1 = new File(fp1.toString());
		File file2 = new File(fp2.toString());
		
		String line;
		try {		
			BufferedReader br = new BufferedReader(new FileReader(file1));
			while ((line = br.readLine()) != null) {
				mListA.add(line);
			}
			br.close();
			
			br = new BufferedReader(new FileReader(file2));
			while ((line = br.readLine()) != null) {
				mListB.add(line);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void printFileData() {
		for (String line : mListA) {
			System.out.println(line);
		}
		for (String line : mListB) {
			System.out.println(line);
		}
	}

}
