package my.system;

import my.sensor.*;
import my.motor.*;
import my.thinker.*;
import my.surroundings.*;

/**
 * RecogSystem :+ {Sensor, Motor, Thinker}    // �ý����� ����, �, ������ ������.
 * RecogSystem -- Surroundings                // �ý����� ���� ȯ�濡 ����ȴ�.
 * @author hyosun.lee
 *
 */
public class RecogSystem {
	private Sensor sensor;
	private Motor motor;
	private Thinker thinker;
	
	public Surroundings surroundings;
	
	public RecogSystem() {
		sensor = new Sensor();
		motor = new Motor();
		thinker = new Thinker();
	}
	
	public void connect(Surroundings s) {
		System.out.println("RecogSystem.connect()");
		surroundings = s;
	}
	
	public void doSense() {
		System.out.println("RecogSystem.doSense()");
		sensor.measure(surroundings.thing);
	}
}
