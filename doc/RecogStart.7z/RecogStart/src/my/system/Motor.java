package my.system;

public class Motor {

}
