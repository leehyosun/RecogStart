package my.system;

public class Sensor {

}
