package my.system;

public class Thinker {

}
