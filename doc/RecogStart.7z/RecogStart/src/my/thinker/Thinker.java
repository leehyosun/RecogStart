package my.thinker;

public class Thinker {

}
