package my.sensor;

public class Data {
	public String value;
}
