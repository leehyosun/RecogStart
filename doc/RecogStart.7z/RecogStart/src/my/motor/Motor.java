package my.motor;

public class Motor {

}
